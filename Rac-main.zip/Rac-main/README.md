# Rac
rants and confessions
